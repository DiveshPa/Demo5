using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class tblExecutive
    {
       public  int c_exeid{get;set;}

       public string c_exemail{get;set;} 

       public string c_password{get;set;}

       public string c_exetype{get;set;}
    }
}