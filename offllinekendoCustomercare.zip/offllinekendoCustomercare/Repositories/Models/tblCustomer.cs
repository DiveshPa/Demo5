using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class tblCustomer
    {
        public int c_customerid{get;set;}

        public string c_customername{get;set;}

        public string c_customermobile{get;set;}

        public string exetype{get;set;}

        public int c_exeid{get;set;}

         public string c_status{get;set;}
    }
}