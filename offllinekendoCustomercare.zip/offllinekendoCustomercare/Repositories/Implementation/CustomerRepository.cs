using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class CustomerRepository : ICustomerRepository
    {
        private NpgsqlConnection _conn;

        private IHttpContextAccessor _httpContextAccessor;

        public CustomerRepository(IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _conn = new NpgsqlConnection(config.GetConnectionString("pgconn"));
            _httpContextAccessor = httpContextAccessor;
        }

        public void AddCustomer(tblCustomer customer)
        {
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("insert into t_customer (c_exeid) values (@exeid)", conn);
                cmd.Parameters.AddWithValue("@exeid", customer.c_exeid);
                cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            }
        }
        public List<tblCustomer> GetCustomers()
        {
            var customers = new List<tblCustomer>();
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c.c_customerid,e.c_exetype,c.c_status from t_customer c inner join t_executive e on c.c_exeid=e.c_exeid", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var customer = new tblCustomer
                    {

                        c_customerid = Convert.ToInt32(reader["c_customerid"]),
                        exetype = reader["c_exetype"].ToString(),
                        c_status = reader["c_status"].ToString()


                    };
                    customers.Add(customer);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            }
            return customers;
        }
        public List<tblExecutive> GetExecutives()
        {
            var exes = new List<tblExecutive>();
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c_exeid,c_exetype from t_executive", conn);

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var exe = new tblExecutive
                    {
                        c_exeid = Convert.ToInt32(reader["c_exeid"]),
                        c_exetype = reader["c_exetype"].ToString()

                    };
                    exes.Add(exe);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();

            }
            }
            return exes;
        }

        public void Login(string email, string password)
        {
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select * from t_executive where c_exemail=@email and c_exepassword=@password", conn);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@password", password);

                var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    var session = _httpContextAccessor.HttpContext.Session;
                    session.SetInt32("exeid", (int)reader["c_exeid"]);
                    session.SetString("exetype", reader["c_exetype"].ToString());
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            }
        }

        public List<tblCustomer> GetCustomersExe(int id)
        {
            var customers = new List<tblCustomer>();
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();

                using var cmd = new NpgsqlCommand("select c.c_customerid,e.c_exetype,c.c_status from t_customer c inner join t_executive e on c.c_exeid=e.c_exeid where c.c_exeid=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var customer = new tblCustomer
                    {

                        c_customerid = Convert.ToInt32(reader["c_customerid"]),
                        exetype = reader["c_exetype"].ToString(),
                        c_status = reader["c_status"].ToString()


                    };
                    customers.Add(customer);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            }
            return customers;
        }

        public tblCustomer GetOneCustomer(int id)
        {
            var customer=new tblCustomer();
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try{
                conn.Open();

                using var cmd=new NpgsqlCommand("select c_customerid, c_exeid,c_status from t_customer where c_customerid=@id",conn);
                cmd.Parameters.AddWithValue("@id",id);

                var reader=cmd.ExecuteReader();

                if(reader.Read())

                {
                    customer.c_customerid=Convert.ToInt32(reader["c_customerid"]);
                    customer.c_exeid=Convert.ToInt32(reader["c_exeid"]);
                    customer.c_status=reader["c_status"].ToString();
                    
                }

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                conn.Close();
            }
            }
            return customer;
        }

        public void UpadateStatus(tblCustomer customer)
        {
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("update t_customer set c_customername=@name,c_customermobile=@mobile,c_status='Resolved' where c_customerid=@id", conn);
                cmd.Parameters.AddWithValue("@id", customer.c_customerid);
                cmd.Parameters.AddWithValue("@name", customer.c_customername);
                cmd.Parameters.AddWithValue("@mobile", customer.c_customermobile);

                cmd.ExecuteNonQuery();

                conn.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            }

        }
        

    }
}