using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface ICustomerRepository
    {
        public void AddCustomer(tblCustomer customer);

        public List<tblCustomer> GetCustomers();

        public List<tblExecutive> GetExecutives();

        public void Login(string email, string password);

        public List<tblCustomer> GetCustomersExe(int id);

        public void UpadateStatus(tblCustomer customer);

         public tblCustomer GetOneCustomer(int id);
    }
}