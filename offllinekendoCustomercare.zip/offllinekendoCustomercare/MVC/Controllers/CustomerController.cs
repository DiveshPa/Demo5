using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class CustomerController : Controller
    {
        private readonly ICustomerRepository _customerRepository;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public CustomerController(ICustomerRepository customerRepository,IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor=httpContextAccessor;
            _customerRepository=customerRepository;
          
        }

        public IActionResult Index()
        {
            List<tblCustomer> customers=_customerRepository.GetCustomers();

            return View(customers);
        }

         public IActionResult IndexExe(int id)
        {
            List<tblCustomer> customers=_customerRepository.GetCustomersExe(id);

            return View(customers);
        }

        public IActionResult Add()
        {
           
            return View();
        }
            [HttpPost]
         public IActionResult Add(tblCustomer customer)
        {
            _customerRepository.AddCustomer(customer);
            return Json(new { success = true});
        }
           public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(tblExecutive user)
        {
            var session=_httpContextAccessor.HttpContext.Session;
            int userId=session.GetInt32("exeid")??0;
            Console.WriteLine(userId);
            _customerRepository.Login(user.c_exemail,user.c_password);

            return Json(new{id=userId});
           
        }

        public IActionResult GetCustomer(int id)
        {
             var customer= _customerRepository.GetOneCustomer(id);

             return Json(customer);
        }

         public IActionResult Edit(int id)
        {

           var customer= _customerRepository.GetOneCustomer(id);
              ViewBag.Executives=_customerRepository.GetExecutives();
           
            return View(customer);
        }

        [HttpPost]
         public IActionResult Edit(tblCustomer customer)
        {
              var session=_httpContextAccessor.HttpContext.Session;

            int userId=session.GetInt32("exeid")??0;
            _customerRepository.UpadateStatus(customer);
            return Json(new{id=userId});
        }

         [Produces("application/json")]
        public IActionResult ListAllExes()
        {
            List<tblExecutive> depts = _customerRepository.GetExecutives();
            return Json(depts);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}